#ifndef BURST_TYPE_TRAITS_VOID_T_HPP
#define BURST_TYPE_TRAITS_VOID_T_HPP

namespace burst
{
    template <typename ...>
    using void_t = void;
} // namespace burst

#endif // BURST_TYPE_TRAITS_VOID_T_HPP
