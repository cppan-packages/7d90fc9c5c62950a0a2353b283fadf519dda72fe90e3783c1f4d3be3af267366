#ifndef BURST_CONTAINER_ACCESS_HPP
#define BURST_CONTAINER_ACCESS_HPP

#include <burst/container/access/back.hpp>
#include <burst/container/access/cback.hpp>
#include <burst/container/access/cfront.hpp>
#include <burst/container/access/front.hpp>

#endif // BURST_CONTAINER_ACCESS_HPP
